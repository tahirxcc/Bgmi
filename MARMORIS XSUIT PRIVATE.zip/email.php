<?php
$emailku = '@gmail.com'; // GANTI EMAIL KAMU DISINI
?>